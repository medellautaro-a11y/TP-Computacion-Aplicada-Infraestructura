#!/bin/bash
set -e

show_help() {
  echo "Uso: $0 <ORIGEN> <DESTINO>"
  echo "Ejemplo: $0 /var/log /backup_dir"
  echo "Crea un .tar.gz en DESTINO con nombre: <base>_bkp_YYYYMMDD.tar.gz"
  echo "Opciones:"
  echo "  -help   Muestra esta ayuda"
}

if [ "$1" = "-help" ] || [ "$1" = "--help" ] || [ $# -eq 0 ]; then
  show_help
  exit 0
fi

if [ $# -ne 2 ]; then
  echo "Error: faltan argumentos."
  show_help
  exit 1
fi

SRC="$1"
DST="$2"
DATE="$(date +%Y%m%d)"
BASE="$(basename "$SRC")"
OUT="${DST}/${BASE}_bkp_${DATE}.tar.gz"

# Validaciones (fs disponible)
if [ ! -d "$SRC" ]; then
  echo "Error: ORIGEN no existe o no es directorio: $SRC"
  exit 2
fi

if [ ! -d "$DST" ]; then
  echo "Error: DESTINO no existe o no es directorio: $DST"
  exit 3
fi

# Validar que se pueda consultar el filesystem del origen/destino
df -P "$SRC" >/dev/null 2>&1 || { echo "Error: filesystem de ORIGEN no disponible: $SRC"; exit 4; }
df -P "$DST" >/dev/null 2>&1 || { echo "Error: filesystem de DESTINO no disponible: $DST"; exit 5; }

# Chequeo extra: destino idealmente montado
mountpoint -q "$DST" || echo "AVISO: $DST no figura como mountpoint (igual intento)."

# Crear backup
tar -C "$SRC" -czf "$OUT" .

echo "OK: Backup creado -> $OUT"
